"""Reproduce the result figures of the paper.

summary.pdf, pareto.pdf and dynamics.pdf are drawn from results/paper/figure_data.json, which collects the
values of the frozen held-out evaluation of experiments/gfn_paper_colab.py (harm rounded to whole episodes
out of 600). scaling.pdf is drawn from the fidelity and timing values reported by the same evaluation.
"""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'figures'
D = json.load(open(ROOT / 'results' / 'paper' / 'figure_data.json'))
COL = {'always': '#adb5bd', 'deployed': '#868E96', 'crisis': '#E8590C', 'cra': '#F08C00', 'msg': '#4C6EF5', 'mem': '#15AABF',
       'shield': '#7048E8', 'maxu': '#C2255C', 'maxs': '#495057', 'exact': '#212529', 'gfn': '#2B8A3E'}
NAME = {'always': 'always helpful', 'deployed': 'deployed-like', 'crisis': 'crisis detection', 'cra': 'risk accumulation',
        'msg': 'message-only filter', 'mem': 'memory-based filter', 'shield': 'myopic shield', 'maxu': 'maximum plan utility',
        'maxs': 'maximum plan safety', 'exact': 'exact mass', 'gfn': 'GFlowNet (proposed)'}
PANELS = [(0, 0, 'main_2'), (0, 1, 'weak_2'), (1, 0, 'main_7'), (1, 1, 'weak_7')]


def style(a, axis='both'):
    a.spines[['top', 'right']].set_visible(False)
    a.grid(alpha=.25, lw=.5, axis=axis)
    a.set_axisbelow(True)


# reduction in harm at delta = 0.05
ORD = ['always', 'deployed', 'crisis', 'cra', 'msg', 'mem', 'shield', 'maxu']
FIX = {'main': {'always': 99.83, 'deployed': 67.67}, 'weak': {'always': 99.83, 'deployed': 73.00}}
fig, axs = plt.subplots(2, 2, figsize=(10, 6.4), sharey=True)
for r, c, pan in PANELS:
    env = pan.split('_')[0]
    F = D['front'][pan]
    g = F['gfn'][1][0]
    H = [FIX[env].get(k, F[k][1][0]) for k in ORD]
    V = [100 * (1 - g / h) for h in H]
    a = axs[r, c]
    y = np.arange(len(ORD))[::-1]
    a.barh(y, V, color=['#2B8A3E' if v > 0.05 else '#adb5bd' for v in V], height=0.7)
    for yi, v, h in zip(y, V, H):
        a.text(max(v, 0) + 1.5, yi, f"{v:.1f}% ({h:.2f}%)", va='center', fontsize=7, color='#495057')
    a.set_xlim(0, 135); a.set_xticks([0, 20, 40, 60, 80, 100]); style(a, 'x')
    a.text(0.98, 0.03, '(' + 'abcd'[2 * r + c] + ')', transform=a.transAxes, ha='right', va='bottom', fontsize=9)
    if r == 1:
        a.set_xlabel('reduction in harm (%)')
axs[0, 0].set_yticks(np.arange(len(ORD))[::-1])
axs[0, 0].set_yticklabels([NAME[k] for k in ORD], fontsize=8)
axs[1, 0].set_yticklabels([NAME[k] for k in ORD], fontsize=8)
fig.tight_layout(); fig.savefig(OUT / 'summary.pdf'); plt.close(fig)

# harm and helpfulness of the GFlowNet and of the safeguards
fig, axs = plt.subplots(2, 2, figsize=(10, 7))
YL = {'main_2': (0, 40), 'main_7': (0, 40), 'weak_2': (0, 100), 'weak_7': (0, 100)}
for r, c, pan in PANELS:
    a = axs[r, c]
    for k in ['crisis', 'cra', 'msg', 'mem', 'gfn']:
        pts = sorted(D['front'][pan][k], key=lambda p: p[1])
        x, yv = [p[1] for p in pts], [p[0] for p in pts]
        a.plot(x, yv, color=COL[k], label=NAME[k], lw=2.4 if k == 'gfn' else 1.3)
        a.plot(x, yv, 'o', color=COL[k], ms=5 if k == 'gfn' else 3.5)
    a.set_xlim(0.54, 0.72); a.set_ylim(*YL[pan]); style(a)
    a.text(0.03, 0.95, '(' + 'abcd'[2 * r + c] + ')', transform=a.transAxes, va='top', fontsize=9)
    if c == 0:
        a.set_ylabel('harm (%)')
    if r == 1:
        a.set_xlabel('helpfulness')
h, l = axs[0, 0].get_legend_handles_labels()
fig.legend(h, l, frameon=False, ncol=5, fontsize=8.5, loc='lower center', bbox_to_anchor=(0.5, -0.02))
fig.tight_layout(rect=[0, 0.06, 1, 1]); fig.savefig(OUT / 'pareto.pdf', bbox_inches='tight'); plt.close(fig)

# cumulative harm and average stage over the turns, k = 2, delta = 0.05
fig, axs = plt.subplots(2, 2, figsize=(10, 6.6))
t = np.arange(31)
for c, env in enumerate(['main', 'weak']):
    for k in ['always', 'deployed', 'crisis', 'cra', 'msg', 'mem', 'shield', 'maxu', 'maxs', 'exact', 'gfn']:
        kw = dict(color=COL[k], label=NAME[k], lw=2.4 if k == 'gfn' else 1.2)
        if k == 'exact':
            kw.update(ls='--', lw=1.3)
        if k == 'maxs':
            kw.update(ls='-.')
        axs[0, c].plot(t, D['dyn'][env][k]['harm'], **kw)
        axs[1, c].plot(t, D['dyn'][env][k]['stage'], **kw)
    for r in (0, 1):
        style(axs[r, c]); axs[r, c].set_xlim(0, 30)
        axs[r, c].text(0.02, 0.97, '(' + 'abcd'[2 * r + c] + ')', transform=axs[r, c].transAxes, ha='left', va='top', fontsize=9)
    axs[1, c].set_xlabel('conversation turn')
axs[0, 0].set_ylabel('cumulative harm (%)'); axs[1, 0].set_ylabel('average escalation stage')
h, l = axs[0, 0].get_legend_handles_labels()
fig.legend(h, l, frameon=False, ncol=4, fontsize=8.5, loc='lower center', bbox_to_anchor=(0.5, -0.02))
fig.tight_layout(rect=[0, 0.08, 1, 1]); fig.savefig(OUT / 'dynamics.pdf', bbox_inches='tight'); plt.close(fig)

# fidelity, time per decision and stored arrays, delta = 0.05
K = [2, 4, 6, 7]
S = {'main': dict(agree=[100.00, 91.21, 90.74, 93.08], gfn=[0.136, 0.137, 0.175, 0.234], exact=[0.014, 0.029, 0.405, 1.972],
                  recomp=[0.081, 0.739, 26.3, 189.661], mem_ex=[0.011, 0.300, 8.22, 42.92], mem_g=[1.42, 1.43, 1.44, 1.44]),
     'weak': dict(agree=[100.00, 93.70, 93.59, 96.80], gfn=[0.134, 0.142, 0.164, 0.214], exact=[0.013, 0.030, 0.395, 1.918],
                  recomp=[0.081, 0.766, 25.2, 182.1], mem_ex=[0.011, 0.300, 8.22, 42.92], mem_g=[1.42, 1.43, 1.44, 1.44])}
fig, ax = plt.subplots(2, 3, figsize=(11, 6.2))
for r, env in enumerate(['main', 'weak']):
    d = S[env]
    ax[r, 0].plot(K, d['agree'], '-o', color='#2B8A3E', lw=1.8, ms=5, label='GFlowNet')
    ax[r, 0].set_ylim(80, 105); ax[r, 0].set_yticks([80, 85, 90, 95, 100]); ax[r, 0].set_ylabel('agreement with exact selection (%)')
    ax[r, 1].plot(K, d['gfn'], '-o', color='#2B8A3E', lw=1.8, ms=5)
    ax[r, 1].plot(K, d['exact'], '-s', color='#495057', lw=1.4, ms=4.5, label='exact selection, precomputed plan values')
    ax[r, 1].plot(K, d['recomp'], '-^', color='#E8590C', lw=1.4, ms=5, label='exact selection, recomputed plan values')
    ax[r, 1].set_yscale('log'); ax[r, 1].set_ylabel('time per decision (ms)')
    ax[r, 2].plot(K, d['mem_g'], '-o', color='#2B8A3E', lw=1.8, ms=5)
    ax[r, 2].plot(K, d['mem_ex'], '--D', color='#7048E8', lw=1.4, ms=4.5, label='exact selection, stored plans and values')
    ax[r, 2].set_yscale('log'); ax[r, 2].set_ylabel('stored arrays (MiB)')
    for j in range(3):
        b = ax[r, j]; style(b); b.set_xticks(K)
        pos = (0.97, 0.06, 'right', 'bottom') if j == 0 else (0.03, 0.95, 'left', 'top')
        b.text(pos[0], pos[1], '(' + 'abcdef'[3 * r + j] + ')', transform=b.transAxes, ha=pos[2], va=pos[3], fontsize=9)
        if r == 1:
            b.set_xlabel('planning horizon $k$')
hs, ls = [], []
for b in ax[0]:
    h, l = b.get_legend_handles_labels(); hs += h; ls += l
fig.legend(hs, ls, frameon=False, ncol=2, fontsize=8.5, loc='lower center', bbox_to_anchor=(0.5, -0.02))
fig.tight_layout(rect=[0, 0.08, 1, 1]); fig.savefig(OUT / 'scaling.pdf', bbox_inches='tight'); plt.close(fig)
print('Figures written to', OUT)
