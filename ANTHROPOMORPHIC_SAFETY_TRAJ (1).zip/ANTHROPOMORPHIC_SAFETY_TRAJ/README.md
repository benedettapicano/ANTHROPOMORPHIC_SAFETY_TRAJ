# Sampling Safe Futures

Code and data for the paper *Sampling Safe Futures: Multimodal Trajectory Planning for Personalized Safety in Anthropomorphic AI* (B. Picano, D. Niyato).

The repository contains the simulation environment, the experiment that produces the results of the paper, the figures and the data used to draw them, and the audit of relational cue extraction on real user messages.

## Structure

```
experiments/
  gfn_paper_colab.py          experiment of the paper: prefix-certified GFlowNet, exact reference and
                              baselines, planning horizons k = 2, 4, 6, 7, twenty configurations
simulator/
  validation_engine.py        user response model, belief filtering, safety values, baselines
  llm_corpus/                 synthetic user messages per stage and profile, extracted cues,
                              fitted observation models, corpus checks
results/
  paper/                      outputs of the frozen held-out evaluation (see below)
figures/
  make_figures.py             reproduces the result figures of the paper
  summary.pdf, pareto.pdf, dynamics.pdf, scaling.pdf
audit/
  real_cues_v2_annotated.csv  WildChat messages with reference labels and extractor outputs
  real_cues_v2_metrics.csv    precision and recall per extractor and cue
  annotation_protocol.json    selection and annotation protocol
legacy/                       earlier experiments with a two-step exact planner and an earlier
                              GFlowNet, kept for reference; not used in the paper
```

## Requirements

Python 3.10 or later with `numpy` and `matplotlib` (`pip install -r requirements.txt`). Everything runs on CPU.

## Running the experiment

The script embeds its input files and verifies them by checksum. In Google Colab, paste it in a single cell and run it; outputs are written to `gfn_paper_horizons` in Google Drive, and an interrupted run resumes from the completed configurations. Locally:

```
PAPER_OUT=results/paper/run python experiments/gfn_paper_colab.py
```

Without further options the script runs the configurations of the paper: two environments (fallback pressure -2 and -1), planning horizons k = 2, 4, 6, 7 at safety horizon L = 8, tolerances 0.02, 0.05, 0.1, 0.2 for k = 2 and 7 and 0.05 for k = 4 and 6, with 200 held-out episodes per user profile. `GFN_MODE=smoke` runs a quick functional check on separate seeds. `PAPER_PHASE` (train, evaluate, benchmark, report) runs a single phase.

## Evaluation protocol

All networks and baseline thresholds are fixed on validation episodes and recorded in `protocol_fixed_before_test.json` before any held-out episode is run. Baseline thresholds are calibrated to the strategy utility of the GFlowNet and never on harm. The exact safe continuation mass, obtained by enumerating the plans, is used only as a reference for evaluation. All evaluated configurations are reported.

## Figures

```
python figures/make_figures.py
```

`results/paper/figure_data.json` contains the values used for the figures, taken from the frozen held-out evaluation, with harm expressed as a whole number of episodes out of 600.

## Data

The synthetic corpus in `simulator/llm_corpus/` was generated with Qwen2.5-7B-Instruct, and the cues were extracted with Qwen2.5-1.5B-Instruct, Falcon3-3B-Instruct, SmolLM2-1.7B-Instruct and Phi-3.5-mini-instruct.

The audit messages are taken from WildChat (Zhao et al., *WildChat: 1M ChatGPT Interaction Logs in the Wild*, ICLR 2024), released under the ODC-By license. The 117 relational messages are candidates retrieved through lexical patterns, and the reference labels were assigned by large language models, not by human annotators.
