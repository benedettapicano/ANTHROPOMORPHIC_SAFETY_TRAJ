# Validation only: episode risk allocation, unchanged simulator.
import os,time,json,zipfile
from pathlib import Path
import numpy as np
VERSION="episode-budget-validation-1"
DATA_ROOT=Path(os.environ.get("BUDGET_DATA_ROOT","."))
INPUT_ZIP=None
OUTPUT_DIR=os.environ.get("BUDGET_OUTPUT_DIR","episode_budget_validation")
N_EPISODES_PER_PROFILE=int(os.environ.get("BUDGET_N_EPISODES","200"))
VALIDATION_OFFSET=200000
DOWNLOAD_RESULTS=os.environ.get("BUDGET_DOWNLOAD","1")=="1"
RUN_VALIDATION=os.environ.get("BUDGET_AUTORUN","1")=="1"
CORE_SOURCE='import os\nimport time\nimport json\nimport random\nimport zipfile\nimport matplotlib\nmatplotlib.use("Agg")\nimport matplotlib.pyplot as plt\nimport numpy as np\nfrom itertools import product\n\nQUICK = False\nCORPUS_DIR = "llm_corpus"\nOUT_ROOT = "figures"\nSEED = 0\nMARK_NEW = True\nENVIRONMENTS = [("unit", False), ("acc", True)]\n\nrng = np.random.default_rng(SEED)\n\nM_STAGES, BAD, N_CUES = 5, 4, 4\nSTRATEGIES = [\n    ("reinforce companionship", +2.0, 1.00),\n    ("validate neutrally", +1.0, 0.80),\n    ("stay task oriented", 0.0, 0.60),\n    ("challenge claims", -1.0, 0.45),\n    ("redirect to humans", -2.0, 0.25),\n]\nA, FALLBACK = len(STRATEGIES), len(STRATEGIES) - 1\nPRESSURE = np.array([s[1] for s in STRATEGIES])\nUTIL = np.array([s[2] for s in STRATEGIES])\nESCALATING = PRESSURE > 0\n\nESCALATION_RATIO = 7.4\nSYCOPHANCY_RATE = 0.70\nINFLUENCE_PERSISTENCE = 8\nP_BASE = 0.06\nGAMMA = np.log(ESCALATION_RATIO) / 2.0\nRECOVERY_BASE = 1.0 / INFLUENCE_PERSISTENCE\nLAM = 1.0 - 1.0 / INFLUENCE_PERSISTENCE\nELL_STEP = 0.02\n\nBETA = 1.0\nDELTA, K_PLAN, L_SAFE, N_SAMPLES = 0.10, 2, 8, 64\nT_EPISODE = 30\nN_EPISODES = 8 if QUICK else 60\nGFN_ITERS = 400 if QUICK else 6000\n\nDIV_EPS = 1e-3\n\nPROFILES = {"low": (0.8, 1.2, 1.3), "medium": (1.1, 0.9, 1.1), "high": (1.6, 0.7, 0.9)}\nPROFILE_VEC = {k: np.array(v) for k, v in PROFILES.items()}\n\n\ndef transition_matrix(pressure, susceptibility, recovery):\n    up = np.clip(P_BASE * susceptibility * np.exp(GAMMA * pressure), 0.0, 0.9)\n    dn = np.clip(RECOVERY_BASE * recovery * np.exp(-GAMMA * pressure), 0.0, 0.6)\n    P = np.zeros((M_STAGES, M_STAGES))\n    for z in range(M_STAGES):\n        row = np.zeros(M_STAGES)\n        row[z] = max(1e-6, 1 - up - dn)\n        if z + 1 < M_STAGES:\n            row[z + 1] = up\n        else:\n            row[z] += up\n        if z - 1 >= 0:\n            row[z - 1] = dn\n        else:\n            row[z] += dn\n        P[z] = row / row.sum()\n    return P\n\n\n_TM_CACHE = {}\n\n\ndef tm_cached(p, sus, rec):\n    key = (int(round(p / ELL_STEP)), sus, rec)\n    if key not in _TM_CACHE:\n        _TM_CACHE[key] = transition_matrix(key[0] * ELL_STEP, sus, rec)\n    return _TM_CACHE[key]\n\n\ndef fit_logistic(z, k, n, quadratic):\n    X = np.stack([np.ones_like(z), z] + ([z ** 2] if quadratic else []), 1)\n    w = np.zeros(X.shape[1])\n    for _ in range(100):\n        p = 1 / (1 + np.exp(-(X @ w)))\n        g = X.T @ (k - n * p)\n        H = (X * (n * p * (1 - p))[:, None]).T @ X + 1e-6 * np.eye(len(w))\n        step = np.linalg.solve(H, g)\n        w += step\n        if np.abs(step).max() < 1e-8:\n            break\n    p = np.clip(1 / (1 + np.exp(-(X @ w))), 1e-9, 1 - 1e-9)\n    ll = float(np.sum(k * np.log(p) + (n - k) * np.log(1 - p)))\n    return w, ll\n\n\ndef fit_irt(extractor, profile):\n    z = np.arange(M_STAGES, dtype=float)\n    out = []\n    for c in range(N_CUES):\n        k = np.array([sum(r[c] for r in CUE_ROWS[(extractor, profile, s)]) for s in range(M_STAGES)], float)\n        n = np.array([len(CUE_ROWS[(extractor, profile, s)]) for s in range(M_STAGES)], float)\n        w1, ll1 = fit_logistic(z, k, n, False)\n        w2, ll2 = fit_logistic(z, k, n, True)\n        quad = 2 * (ll2 - ll1) > 3.84\n        w = w2 if quad else w1\n        X = np.stack([np.ones_like(z), z] + ([z ** 2] if quad else []), 1)\n        fitted = 1 / (1 + np.exp(-(X @ w)))\n        entry = {"form": "unimodal" if quad else "monotone", "coef": w.tolist(),\n                 "fitted": fitted.tolist(), "empirical": (k / n).tolist(),\n                 "max_abs_error": float(np.abs(fitted - k / n).max())}\n        if not quad:\n            entry["discrimination"] = float(w[1])\n            entry["difficulty"] = float(-w[0] / w[1]) if abs(w[1]) > 1e-9 else float("nan")\n        out.append(entry)\n    E = np.clip(np.array([e["fitted"] for e in out]).T, 0.03, 0.97)\n    return E, out\n\n\nMETA = json.load(open(f"{CORPUS_DIR}/emission.json"))\nEXTRACTORS, HELD_OUT = META["extractors"], META["held_out"]\nCUE_ROWS = {}\nwith open(f"{CORPUS_DIR}/corpus.jsonl") as f:\n    for line in f:\n        c = json.loads(line)\n        for m, cues in c["cues"].items():\n            CUE_ROWS.setdefault((m, c["profile"], c["stage"]), []).append(cues)\n\nIRT_E, IRT_REPORT = {}, {}\nfor m in EXTRACTORS + [HELD_OUT]:\n    for p in PROFILES:\n        IRT_E[(m, p)], IRT_REPORT[(m, p)] = fit_irt(m, p)\n\n\ndef make_user_model(profile, E, acc):\n    susceptibility, recovery, _ = profile\n    P = np.stack([transition_matrix(PRESSURE[a], susceptibility, recovery) for a in range(A)])\n    return {"P": P, "E": E, "profile": np.array(profile), "sus": float(susceptibility),\n            "rec": float(recovery), "acc": acc}\n\n\ndef model_step(model, a, ell):\n    if not model["acc"]:\n        return model["P"][a], 0.0\n    ell_next = LAM * ell + (1.0 - LAM) * PRESSURE[a]\n    return tm_cached(ell_next, model["sus"], model["rec"]), ell_next\n\n\ndef uncertainty_set(key, M=3, spread=0.25, seed=0, acc=False):\n    r = np.random.default_rng(seed)\n    out = []\n    for m in range(M):\n        pert = np.array(PROFILES[key]) * (1 + spread * r.uniform(-1, 1, 3))\n        out.append(make_user_model(tuple(pert), IRT_E[(EXTRACTORS[m % len(EXTRACTORS)], key)], acc))\n    return out\n\n\ndef emit(model, z, r):\n    return (r.random(N_CUES) < model["E"][z]).astype(int)\n\n\ndef belief_update(model, b, P, o):\n    E = model["E"]\n    lik = np.prod(np.where(o[None, :] == 1, E, 1 - E), axis=1)\n    post = (b @ P) * lik\n    s = post.sum()\n    return post / s if s > 1e-12 else np.ones(M_STAGES) / M_STAGES\n\n\ndef single_message_posterior(model, o):\n    E = model["E"]\n    lik = np.prod(np.where(o[None, :] == 1, E, 1 - E), axis=1)\n    s = lik.sum()\n    return lik / s if s > 1e-12 else np.ones(M_STAGES) / M_STAGES\n\n\ndef executed(plan, L):\n    return list(plan) + [FALLBACK] * (L - len(plan))\n\n\ndef plan_safe_prob(model, plan, L, ell0=0.0):\n    Ps, ell = [], ell0\n    for a in executed(plan, L):\n        P, ell = model_step(model, a, ell)\n        Ps.append(P)\n    f = np.ones(M_STAGES)\n    f[BAD] = 0.0\n    for P in reversed(Ps):\n        f = P @ f\n        f[BAD] = 0.0\n    return f\n\n\ndef plan_utility(plan):\n    return float(sum(UTIL[a] for a in plan))\n\n\ndef kl_smoothed(p, q, eps=DIV_EPS):\n    p = (p + eps) / (p + eps).sum()\n    q = (q + eps) / (q + eps).sum()\n    return float(np.sum(p * np.log(p / q)))\n\n\nclass SafetyTable:\n    def __init__(self, ensemble, k=K_PLAN, L=L_SAFE):\n        self.plans = list(product(range(A), repeat=k))\n        self.idx = {p: i for i, p in enumerate(self.plans)}\n        self.k, self.L, self.ens = k, L, ensemble\n        self.acc = ensemble[0]["acc"]\n        self._cache = {}\n        self.F_at(0.0)\n\n    def F_at(self, ell):\n        key = int(round(ell / ELL_STEP)) if self.acc else 0\n        if key not in self._cache:\n            e = key * ELL_STEP\n            self._cache[key] = [np.stack([plan_safe_prob(m, p, self.L, e) for p in self.plans]) for m in self.ens]\n        return self._cache[key]\n\n    def value(self, beliefs, i, ell=0.0, robust=True):\n        F = self.F_at(ell)\n        if robust:\n            return min(float(beliefs[m] @ F[m][i]) for m in range(len(F)))\n        return float(beliefs[0] @ F[0][i])\n\n    def admissible(self, beliefs, delta, ell=0.0, robust=True):\n        ok = [i for i in range(len(self.plans)) if self.value(beliefs, i, ell, robust) >= 1 - delta]\n        return ok, sorted({self.plans[i][0] for i in ok})\n\n    def reward(self, beliefs, b_nom, delta, i, ell=0.0, robust=True):\n        if self.value(beliefs, i, ell, robust) < 1 - delta:\n            return 0.0\n        return float(b_nom @ self.F_at(ell)[0][i]) * np.exp(BETA * plan_utility(self.plans[i]))\n\n\nclass MLP:\n    def __init__(self, sizes, seed=0, lr=3e-3):\n        r = np.random.default_rng(seed)\n        self.W = [r.standard_normal((a, b)) * np.sqrt(2 / a) for a, b in zip(sizes[:-1], sizes[1:])]\n        self.b = [np.zeros(b) for b in sizes[1:]]\n        self.lr, self.t = lr, 0\n        self.mW = [np.zeros_like(w) for w in self.W]\n        self.vW = [np.zeros_like(w) for w in self.W]\n        self.mb = [np.zeros_like(x) for x in self.b]\n        self.vb = [np.zeros_like(x) for x in self.b]\n\n    def forward(self, x):\n        self.h = [x]\n        for i, (w, b) in enumerate(zip(self.W, self.b)):\n            z = self.h[-1] @ w + b\n            self.h.append(np.tanh(z) if i < len(self.W) - 1 else z)\n        return self.h[-1]\n\n    def backward(self, dout):\n        gW, gb, d = [None] * len(self.W), [None] * len(self.W), dout\n        for i in reversed(range(len(self.W))):\n            gW[i], gb[i] = self.h[i].T @ d, d.sum(0)\n            if i > 0:\n                d = (d @ self.W[i].T) * (1 - self.h[i] ** 2)\n        self.t += 1\n        for i in range(len(self.W)):\n            for p, g, m, v in ((self.W, gW, self.mW, self.vW), (self.b, gb, self.mb, self.vb)):\n                m[i] = 0.9 * m[i] + 0.1 * g[i]\n                v[i] = 0.999 * v[i] + 0.001 * g[i] ** 2\n                p[i] -= self.lr * (m[i] / (1 - 0.9 ** self.t)) / (np.sqrt(v[i] / (1 - 0.999 ** self.t)) + 1e-8)\n\n\ndef log_softmax_masked(logits, mask):\n    z = np.where(mask, logits, -1e9)\n    z = z - z.max(1, keepdims=True)\n    return z - np.log(np.exp(z).sum(1, keepdims=True))\n\n\ndef sample_training_belief():\n    z = rng.choice(M_STAGES, p=[0.35, 0.30, 0.20, 0.10, 0.05])\n    b = np.full(M_STAGES, 0.05) + np.eye(M_STAGES)[z] * rng.uniform(0.5, 3.0)\n    b = b + rng.dirichlet(np.ones(M_STAGES) * 0.5) * 0.3\n    return b / b.sum()\n\n\nclass GFlowNet:\n    def __init__(self, k=K_PLAN, seed=1, lr=5e-4, use_ell=False):\n        self.k, self.use_ell = k, use_ell\n        self.nc = M_STAGES + 3 + (1 if use_ell else 0)\n        self.dim = self.nc + k + k * A\n        self.net = MLP([self.dim, 64, 64, A], seed=seed, lr=lr)\n        self.zn = MLP([self.nc, 32, 1], seed=seed + 7, lr=1e-3)\n\n    def cond(self, b, xu, ell):\n        parts = [b, xu]\n        if self.use_ell:\n            parts.append(np.array([ell]))\n        return np.concatenate(parts)\n\n    def feats(self, b, xu, ell, step, partial):\n        x = np.zeros(self.dim)\n        x[:self.nc] = self.cond(b, xu, ell)\n        x[self.nc + step] = 1.0\n        for j, a in enumerate(partial):\n            x[self.nc + self.k + j * A + a] = 1.0\n        return x\n\n    @staticmethod\n    def allowed_at(ok_plans, tb, prefix):\n        j = len(prefix)\n        return sorted({tb.plans[i][j] for i in ok_plans if tb.plans[i][:j] == tuple(prefix)})\n\n    def sample(self, b, xu, ell, n, tb, ok_plans):\n        plans = []\n        for _ in range(n):\n            partial = []\n            for step in range(self.k):\n                al = self.allowed_at(ok_plans, tb, partial) or list(range(A))\n                mask = np.zeros((1, A), bool)\n                mask[0, al] = True\n                ls = log_softmax_masked(self.net.forward(self.feats(b, xu, ell, step, partial)[None]), mask)[0]\n                partial.append(int(rng.choice(A, p=np.exp(ls))))\n            plans.append(tuple(partial))\n        return plans\n\n    def train(self, tables, delta, iters=GFN_ITERS, batch=32, robust=True):\n        keys = list(tables)\n        losses = []\n        for _ in range(iters):\n            tb, xu = tables[keys[rng.integers(len(keys))]]\n            b = sample_training_belief()\n            ell = float(rng.uniform(-2.0, 2.0)) if self.use_ell else 0.0\n            beliefs = [b] * len(tb.ens)\n            ok, allowed = tb.admissible(beliefs, delta, ell, robust)\n            if not allowed:\n                continue\n            plans = self.sample(b, xu, ell, batch, tb, ok)\n            logR = np.log([max(tb.reward(beliefs, b, delta, tb.idx[p], ell, robust), 1e-12) for p in plans])\n            X = np.array([self.feats(b, xu, ell, s, p[:s]) for p in plans for s in range(self.k)])\n            ACT = np.array([p[s] for p in plans for s in range(self.k)])\n            mask = np.zeros((len(X), A), bool)\n            for bi, p in enumerate(plans):\n                for s in range(self.k):\n                    for a in self.allowed_at(ok, tb, list(p[:s])):\n                        mask[bi * self.k + s, a] = True\n            ls = log_softmax_masked(self.net.forward(X), mask)\n            logpf = ls[np.arange(len(X)), ACT].reshape(batch, self.k).sum(1)\n            cond = self.cond(b, xu, ell)[None]\n            lz = self.zn.forward(cond)[0, 0]\n            resid = lz + logpf - logR\n            losses.append(float((resid ** 2).mean()))\n            d = 2 * resid / batch\n            dout = -np.exp(ls) * np.repeat(d, self.k)[:, None]\n            dout[np.arange(len(X)), ACT] += np.repeat(d, self.k)\n            self.net.backward(dout)\n            self.zn.forward(cond)\n            self.zn.backward(np.array([[float(d.sum())]]))\n        return losses\n\n\ndef pol_helpful(**kw):\n    return 0, False\n\n\ndef pol_deployed(**kw):\n    if rng.random() < SYCOPHANCY_RATE:\n        return int(rng.integers(0, 2)), False\n    return int(rng.integers(2, A)), False\n\n\nTURN_TAU = [None]\n\n\ndef turnlevel_choice(table, obs, ell, tau):\n    m0 = table.ens[0]\n    if obs is None:\n        b_cur = np.eye(M_STAGES)[0]\n    else:\n        b_cur = single_message_posterior(m0, obs)\n    risk = [float((b_cur @ model_step(m0, a, ell)[0])[BAD]) for a in range(A)]\n    ok = [a for a in range(A) if risk[a] <= tau]\n    return (max(ok, key=lambda a: UTIL[a]) if ok else FALLBACK), False\n\n\ndef pol_turnlevel(table, delta, obs, ell=0.0, **kw):\n    tau = TURN_TAU[0] if TURN_TAU[0] is not None else delta / table.L\n    return turnlevel_choice(table, obs, ell, tau)\n\n\ndef pol_turnlevel_fixed(table, delta, obs, ell=0.0, **kw):\n    return turnlevel_choice(table, obs, ell, delta / table.L)\n\n\ndef pol_reactive(b_nom, **kw):\n    return (FALLBACK if b_nom[3:].sum() > 0.35 else 0), False\n\n\ndef pol_cra(state, b_nom, **kw):\n    s = state.setdefault("cra", {"hist": [], "b0": b_nom.copy()})\n    drift = 1 - float(b_nom @ s["b0"]) / (np.linalg.norm(b_nom) * np.linalg.norm(s["b0"]) + 1e-9)\n    s["hist"].append(float(b_nom[3:].sum()))\n    w = s["hist"][-6:]\n    slope = float(np.polyfit(range(len(w)), w, 1)[0]) if len(w) > 2 else 0.0\n    score = 0.35 * drift + 0.45 * float(b_nom[3:].sum()) + 0.20 * max(slope, 0.0) * 6\n    return (FALLBACK if score > 0.45 else 0), False\n\n\ndef pol_shield(table, beliefs, delta, ell=0.0, robust=True, **kw):\n    _, acts = table.admissible(beliefs, delta, ell, robust)\n    return (max(acts, key=lambda a: UTIL[a]) if acts else FALLBACK), (not acts)\n\n\ndef pol_proposed(table, beliefs, b_nom, xu, gfn, delta, ell=0.0, n_samples=N_SAMPLES, robust=True, **kw):\n    ok, acts = table.admissible(beliefs, delta, ell, robust)\n    if not acts:\n        return FALLBACK, True\n    counts = np.zeros(A)\n    for p in gfn.sample(b_nom, xu, ell, n_samples, table, ok):\n        counts[p[0]] += 1\n    return int(counts.argmax()), False\n\n\nPOLICIES = {\n    "always helpful": pol_helpful,\n    "deployed-like (70% sycophantic)": pol_deployed,\n    "turn-level filter (current turn)": pol_turnlevel,\n    "crisis detection": pol_reactive,\n    "CRA accumulation": pol_cra,\n    "shield + myopic": pol_shield,\n    "proposed": pol_proposed,\n    "turn-level filter (fixed threshold)": pol_turnlevel_fixed,\n}\nUSES_ADMISSIBLE = {"shield + myopic", "proposed"}\n\n\ndef run_episode(policy, user, table, gfn, xu, delta, T=T_EPISODE, seed=0, n_samples=N_SAMPLES, robust=True,\n                profile=None):\n    r = np.random.default_rng(seed)\n    z, ell = 0, 0.0\n    beliefs = [np.eye(M_STAGES)[0].copy() for _ in table.ens]\n    state, util, fb, empty = {}, 0.0, 0, 0\n    harmed = False\n    o = None\n    harm_t, stage_t = np.zeros(T), np.zeros(T)\n    mis_mem, mis_msg = 0, 0\n    p_sum, q_cnt = np.zeros(M_STAGES), np.zeros(M_STAGES)\n    n3, esc3 = 0, 0\n    hi_flt, hi_mem, n_hi = 0.0, 0.0, 0\n    lo_flt, lo_mem, n_lo = 0.0, 0.0, 0\n    m0 = table.ens[0]\n    for t in range(T):\n        b_nom = np.mean(beliefs, axis=0)\n        a, was_empty = policy(table=table, beliefs=beliefs, b_nom=b_nom, xu=xu, gfn=gfn, delta=delta,\n                              n_samples=n_samples, robust=robust, state=state, obs=o, ell=ell)\n        fb += (a == FALLBACK)\n        empty += was_empty\n        util += UTIL[a]\n        if z == BAD - 1:\n            n3 += 1\n            esc3 += int(ESCALATING[a])\n        P_user, ell_next = model_step(user, a, ell)\n        z = r.choice(M_STAGES, p=P_user[z])\n        harmed = harmed or (z == BAD)\n        harm_t[t], stage_t[t] = harmed, z\n        o = emit(user, z, r)\n        beliefs = [belief_update(m, b, model_step(m, a, ell)[0], o) for m, b in zip(table.ens, beliefs)]\n        ell = ell_next\n        b_new = np.mean(beliefs, axis=0)\n        b_msg = np.mean([single_message_posterior(m, o) for m in table.ens], axis=0)\n        b_flt = single_message_posterior(m0, o)\n        mis_mem += int(b_new.argmax() != z)\n        mis_msg += int(b_msg.argmax() != z)\n        p_sum += b_new\n        q_cnt[z] += 1\n        if z >= BAD - 1:\n            hi_flt += float(b_flt[BAD - 1:].sum())\n            hi_mem += float(b_new[BAD - 1:].sum())\n            n_hi += 1\n        else:\n            lo_flt += float(b_flt[BAD - 1:].sum())\n            lo_mem += float(b_new[BAD - 1:].sum())\n            n_lo += 1\n    return dict(profile=profile, harmful=harmed, utility=util / T, fallback=fb / T, empty=empty / T,\n                harm_curve=harm_t, stage_curve=stage_t,\n                smr=mis_mem / T, smr_msg=mis_msg / T, div=kl_smoothed(p_sum / T, q_cnt / T),\n                esc3=(esc3, n3), hi_flt=(hi_flt, n_hi), hi_mem=(hi_mem, n_hi),\n                lo_flt=(lo_flt, n_lo), lo_mem=(lo_mem, n_lo))\n\n\ndef evaluate(policy, users, tables, gfn, delta, n_ep=N_EPISODES, n_samples=N_SAMPLES, robust=True, seed_offset=0):\n    res = []\n    for ui, (key, user) in enumerate(users.items()):\n        tb, xu = tables[key]\n        for ep in range(n_ep):\n            res.append(run_episode(policy, user, tb, gfn, xu, delta, seed=seed_offset + 1000 * ui + ep,\n                                   n_samples=n_samples, robust=robust, profile=key))\n    return res\n\n\ndef pooled(res, key):\n    num = sum(r[key][0] for r in res)\n    den = sum(r[key][1] for r in res)\n    return float(num / den) if den > 0 else float("nan")\n\n\ndef summarize(res):\n    return dict(harmful=float(np.mean([r["harmful"] for r in res])),\n                utility=float(np.mean([r["utility"] for r in res])),\n                fallback=float(np.mean([r["fallback"] for r in res])),\n                empty=float(np.mean([r["empty"] for r in res])),\n                harm_curve=np.mean([r["harm_curve"] for r in res], axis=0),\n                stage_curve=np.mean([r["stage_curve"] for r in res], axis=0),\n                smr=float(np.mean([r["smr"] for r in res])),\n                smr_msg=float(np.mean([r["smr_msg"] for r in res])),\n                div=float(np.mean([r["div"] for r in res])),\n                esc3=pooled(res, "esc3"), hi_flt=pooled(res, "hi_flt"), hi_mem=pooled(res, "hi_mem"),\n                lo_flt=pooled(res, "lo_flt"), lo_mem=pooled(res, "lo_mem"))\n\n\ndef summarize_by_profile(res):\n    out = {}\n    for p in PROFILES:\n        sub = [r for r in res if r["profile"] == p]\n        out[p] = {"harm": 100 * float(np.mean([r["harmful"] for r in sub])),\n                  "utility": float(np.mean([r["utility"] for r in sub])),\n                  "fallback": 100 * float(np.mean([r["fallback"] for r in sub]))}\n    return out\n\n\ndef build(delta=DELTA, L=L_SAFE, k=K_PLAN, M=3, iters=GFN_ITERS, acc=False):\n    users = {key: make_user_model(v, IRT_E[(HELD_OUT, key)], acc) for key, v in PROFILES.items()}\n    tables = {key: (SafetyTable(uncertainty_set(key, M=M, seed=i + 1, acc=acc), k=k, L=L), PROFILE_VEC[key])\n              for i, key in enumerate(PROFILES)}\n    g = GFlowNet(k=k, lr=5e-4, use_ell=acc)\n    if iters > 0:\n        g.train(tables, delta, iters=iters)\n    return users, tables, g\n\n\ndef calibrate_turn_level(users, tables, g, delta):\n    ref = summarize(evaluate(pol_proposed, users, tables, g, delta, n_ep=4 if QUICK else 20, seed_offset=500000))\n    n_cal = 4 if QUICK else 20\n    best = None\n    for tau in np.geomspace(1e-3, 0.5, 16):\n        TURN_TAU[0] = float(tau)\n        u = summarize(evaluate(pol_turnlevel, users, tables, g, delta, n_ep=n_cal, seed_offset=500000))["utility"]\n        if best is None or abs(u - ref["utility"]) < best[1]:\n            best = (float(tau), abs(u - ref["utility"]))\n    TURN_TAU[0] = best[0]\n'

import csv, hashlib, contextlib
from collections import OrderedDict
from statistics import NormalDist
from itertools import product

PLANS=np.array(list(product(range(5),repeat=2)),dtype=int)
OBS=np.array(list(product([0,1],repeat=4)),dtype=int)
TOL=1e-10

def serial(x):
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,np.generic):return x.item()
    if isinstance(x,Path):return str(x)
    raise TypeError(type(x).__name__)

def dump(path,x):
    Path(path).write_text(json.dumps(x,indent=2,default=serial,allow_nan=False))

def inputs():
    root=Path(DATA_ROOT).resolve()
    if (root/'llm_corpus/corpus.jsonl').exists():return root
    candidates=[Path(INPUT_ZIP)] if INPUT_ZIP else list(root.glob('results_all*.zip'))
    if len(candidates)!=1:raise FileNotFoundError('Caricare results_all.zip o impostare DATA_ROOT/INPUT_ZIP.')
    out=root/'budget_validation_inputs'
    with zipfile.ZipFile(candidates[0]) as z:
        for rel in ['llm_corpus/corpus.jsonl','llm_corpus/emission.json']:
            found=[n for n in z.namelist() if n==rel or n.endswith('/'+rel)]
            if len(found)!=1:raise ValueError('Input mancante/ambiguo: '+rel)
            if z.getinfo(found[0]).file_size>50_000_000:raise ValueError('Input troppo grande')
            p=out/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(found[0]))
    return out

def wilson(k,n):
    z=NormalDist().inv_cdf(.975);p=k/n;d=1+z*z/n
    c=(p+z*z/(2*n))/d;h=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return [max(0.,float(c-h)),min(1.,float(c+h))]

class Kernel:
    """Exact finite-horizon first-hit probabilities for two actions + fallback.

    No rounding of initial ell: only the transition quantization already
    present in the original simulator. Cache keys are full pressure patterns.
    """
    def __init__(self,ensemble):
        self.ens=ensemble;self.acc=ensemble[0]['acc'];self.cache=OrderedDict()
        self.Q=np.array([[S['transition_matrix'](key*S['ELL_STEP'],m['sus'],m['rec'])[:4,:4]
                          for key in range(-100,101)] for m in ensemble]) if self.acc else None
        self.P=np.array([m['P'] for m in ensemble])
    def F(self,remaining,ell):
        if remaining==0:
            return np.broadcast_to(np.array([1.,1.,1.,1.,0.]),(len(self.ens),25,5)).copy()
        if self.acc:
            e=np.full(25,ell);keys=np.empty((remaining,25),dtype=np.int16)
            for j in range(remaining):
                a=PLANS[:,j] if j<2 else 4
                e=S['LAM']*e+(1-S['LAM'])*S['PRESSURE'][a]
                keys[j]=np.rint(e/S['ELL_STEP']).astype(np.int16)
            key=(remaining,keys.tobytes())
        else:key=remaining
        if key in self.cache:
            self.cache.move_to_end(key);return self.cache[key]
        f=np.ones((len(self.ens),25,4))
        for j in reversed(range(remaining)):
            if self.acc:Q=self.Q[:,keys[j]+100]
            else:
                a=PLANS[:,j] if j<2 else np.full(25,4)
                Q=self.P[:,a,:4,:4]
            f=np.einsum('mpij,mpj->mpi',Q,f)
        F=np.pad(f,((0,0),(0,0),(0,1)))
        self.cache[key]=F
        if len(self.cache)>4096:self.cache.popitem(last=False)
        return F
    def risks(self,q,remaining,ell):
        return np.clip(1-np.einsum('ms,mps->mp',q[:,0],self.F(remaining,ell)),0,1)

def augmented_update(q,ensemble,a,ell,obs):
    """q[m,0,z]=P(z,never hit BAD|history), q[m,1,z]=P(z,already hit|history)."""
    result=np.empty_like(q);obs_probs=[]
    for mi,m in enumerate(ensemble):
        P,_=S['model_step'](m,a,ell)
        pred=q[mi]@P
        pred[1,4]+=pred[0,4];pred[0,4]=0.
        lik=np.prod(np.where(obs[None,:]==1,m['E'],1-m['E']),axis=1)
        unnorm=pred*lik
        normalizer=unnorm.sum()
        if normalizer<=0:raise FloatingPointError('Osservazione a probabilita nulla')
        result[mi]=unnorm/normalizer;obs_probs.append(normalizer)
    return result,np.array(obs_probs)

def budget_action(kernel,q,budget,remaining,ell,kind):
    risks=kernel.risks(q,remaining,ell)
    ok=np.all(risks<=budget[:,None]+TOL,axis=0)
    if remaining==1:ok &= PLANS[:,1]==4
    if not ok.any():
        # No silent fallback or budget reset: this is a failed certificate.
        raise RuntimeError('Nessun piano certificato: budget/rischio incoerenti.')
    if kind=='budget_myopic':
        a=min(PLANS[ok,0])  # utilities strictly decrease with action index
    else:
        safe_nom=np.mean(q[:,0],axis=0)@kernel.F(remaining,ell)[0].T
        utilities=S['UTIL'][PLANS[:,:min(remaining,2)]].sum(axis=1)
        rewards=np.where(ok,safe_nom*np.exp(S['BETA']*utilities),0.)
        mass=np.bincount(PLANS[:,0],weights=rewards,minlength=5)
        if rewards.sum()<=0: a=min(PLANS[ok,0])
        else:a=int(mass.argmax())
    compatible=np.flatnonzero(ok & (PLANS[:,0]==a))
    slack=np.min(budget[:,None]-risks[:,compatible],axis=0)
    witness=int(compatible[slack.argmax()])
    leftover=np.maximum(budget-risks[:,witness],0.)
    return a,witness,leftover,risks[:,witness]

def carry_budget(kernel,qnew,leftover,witness,remaining_next,ell_next):
    continuation=int(PLANS[witness,1])*5+4
    risk_tail=kernel.risks(qnew,remaining_next,ell_next)[:,continuation]
    return np.minimum(1.,risk_tail+leftover),risk_tail

def original_gfn_action(g,tb,b,ell,xu,delta,random):
    ok,acts=tb.admissible(b,delta,ell,True)
    if not acts:return 4,True
    feat=g.feats(b.mean(axis=0),xu,ell,0,[])[None]
    mask=np.zeros((1,5),dtype=bool);mask[0,acts]=True
    prob=np.exp(S['log_softmax_masked'](g.net.forward(feat),mask)[0])
    # First-step marginal is sufficient for voting. Second-action samples
    # do not affect the first-action vote; distribution is unchanged.
    return int(np.bincount(random.choice(5,size=64,p=prob),minlength=5).argmax()),False

def episode(kind,param,user,tb,kernel,xu,g,seed,policy_seed):
    env=np.random.default_rng(seed);rand=np.random.default_rng(policy_seed)
    q=np.zeros((len(tb.ens),2,5));q[:,0,0]=1.
    budget=np.full(len(tb.ens),param if kind.startswith('budget_') else 1.)
    z,ell,obs=0,0.,None
    harmed=False;utility=0.;fallback=empty_count=0;first_harm_emergency=False
    smallest_slack=1.;state={};history=[]
    for t in range(30):
        b=q.sum(axis=1);bn=b.mean(axis=0);remaining=30-t;empty=False
        if kind.startswith('budget_'):
            a,witness,leftover,planrisk=budget_action(kernel,q,budget,remaining,ell,kind)
            smallest_slack=min(smallest_slack,float(np.min(budget-planrisk)))
        elif kind in ['turn_message','turn_memory']:
            cur=(np.eye(5)[0] if obs is None else S['single_message_posterior'](tb.ens[0],obs)) if kind=='turn_message' else b[0]
            risk=np.array([(cur@S['model_step'](tb.ens[0],a0,ell)[0])[4] for a0 in range(5)])
            allowed=np.flatnonzero(risk<=param)
            a=int(allowed[0]) if len(allowed) else 4
        elif kind=='always_helpful':a=0
        elif kind=='deployed':
            a=int(rand.integers(0,2)) if rand.random()<.7 else int(rand.integers(2,5))
        elif kind=='crisis':a=4 if bn[3:].sum()>param else 0
        elif kind=='CRA':
            if not history:initial=bn.copy()
            drift=1-float(bn@initial)/(np.linalg.norm(bn)*np.linalg.norm(initial)+1e-9)
            history.append(float(bn[3:].sum()));w=history[-6:]
            slope=float(np.polyfit(range(len(w)),w,1)[0]) if len(w)>2 else 0.
            score=.35*drift+.45*float(bn[3:].sum())+.20*max(slope,0)*6
            a=4 if score>param else 0
        elif kind=='original_gfn':a,empty=original_gfn_action(g,tb,b,ell,xu,param,rand)
        else:
            F=np.asarray(tb.F_at(ell))
            value=np.einsum('ms,mps->mp',b,F).min(axis=0)
            ok=value>=1-param
            if not ok.any():a=4;empty=True
            elif kind=='shield':a=int(PLANS[ok,0].min())
            elif kind=='original_exact':
                reward=(bn@F[0].T)*np.exp(S['UTIL'][PLANS].sum(axis=1))
                reward[~ok]=0.
                a=int(np.bincount(PLANS[:,0],weights=reward,minlength=5).argmax())
            else:raise ValueError(kind)
        utility+=S['UTIL'][a];fallback+=a==4;empty_count+=empty
        P,e=S['model_step'](user,a,ell)
        z=env.choice(5,p=P[z]);obs=S['emit'](user,z,env)
        if z==4 and not harmed:first_harm_emergency=bool(empty)
        harmed=harmed or z==4
        qnew,_=augmented_update(q,tb.ens,a,ell,obs)
        if kind.startswith('budget_'):
            budget,tail=carry_budget(kernel,qnew,leftover,witness,remaining-1,e)
            if np.max(tail-budget)>TOL:raise AssertionError('Continuzione non ammissibile')
        q,ell=qnew,e
    if kind.startswith('budget_'):
        if np.any(q[:,1].sum(axis=1)>budget+TOL):raise AssertionError('Certificato terminale violato')
    return {'harm':int(harmed),'utility':utility/30,'fallback':fallback/30,'emergency':empty_count/30,
            'first_harm_emergency':int(harmed and first_harm_emergency),
            'first_harm_not_emergency':int(harmed and not first_harm_emergency),
            'minimum_certificate_slack':smallest_slack if kind.startswith('budget_') else None}

def summarize(rows):
    n=len(rows);hits=sum(r['harm'] for r in rows)
    groups=[[r for r in rows if r['profile']==p] for p in S['PROFILES']]
    var=sum(np.var([r['utility'] for r in group],ddof=1)/len(group) for group in groups)/9
    helpmean=float(np.mean([r['utility'] for r in rows]));se=float(np.sqrt(var))
    return {'n':n,'harm_count':hits,'harm':hits/n,'harm_wilson95_approx':wilson(hits,n),
            'utility':helpmean,'utility_normal95_stratified':[helpmean-1.96*se,helpmean+1.96*se],
            'fallback':float(np.mean([r['fallback'] for r in rows])),
            'emergency':float(np.mean([r['emergency'] for r in rows])),
            'harm_after_emergency':sum(r['first_harm_emergency'] for r in rows),
            'harm_without_emergency':sum(r['first_harm_not_emergency'] for r in rows),
            'per_profile':{p:{'n':len(group),'harm':sum(r['harm'] for r in group)/len(group),
                              'harm_wilson95_approx':wilson(sum(r['harm'] for r in group),len(group)),
                              'utility':float(np.mean([r['utility'] for r in group]))}
                           for p,group in zip(S['PROFILES'],groups)}}

def check_certificate(users,tables,kernels):
    r=np.random.default_rng(731);max_tower=0.;max_matrix=0.;checked=0
    for p,(tb,xu) in tables.items():
        kernel=kernels[p]
        for remaining,ell in [(30,0.),(12,.137),(3,-.277),(1,.419)]:
            if not kernel.acc:ell=0.
            F=kernel.F(remaining,ell)
            for mi,m in enumerate(tb.ens):
                for i in [0,4,12,24]:
                    expected=S['plan_safe_prob'](m,tuple(PLANS[i][:min(remaining,2)]),remaining,ell)
                    max_matrix=max(max_matrix,float(np.max(abs(expected-F[mi,i]))))
            q=np.zeros((3,2,5));q[:,0,:4]=r.dirichlet(np.ones(4),size=3)*.95
            q[:,1,:]=r.dirichlet(np.ones(5),size=3)*.05
            budget=np.minimum(1.,kernel.risks(q,remaining,ell)[:,24]+.15)
            a,witness,slack,rho=budget_action(kernel,q,budget,remaining,ell,'budget_exact')
            _,elln=S['model_step'](tb.ens[0],a,ell)
            average_rho=np.zeros(3);average_budget=np.zeros(3);total=np.zeros(3)
            for obs in OBS:
                qn,prob=augmented_update(q,tb.ens,a,ell,obs)
                bn,tail=carry_budget(kernel,qn,slack,witness,remaining-1,elln)
                average_rho+=prob*tail;average_budget+=prob*bn;total+=prob
                assert np.all(tail<=bn+TOL)
                if remaining>1:budget_action(kernel,qn,bn,remaining-1,elln,'budget_exact')
                checked+=1
            np.testing.assert_allclose(total,1.,atol=1e-12)
            max_tower=max(max_tower,float(np.max(abs(average_rho-rho))))
            assert np.all(average_budget<=budget+1e-12)
    assert max_matrix<1e-12 and max_tower<1e-12
    print(f'PASS: {checked} observation branches; survival error={max_matrix:.2g}, tower error={max_tower:.2g}',flush=True)
    return {'observation_branches_checked':checked,'max_survival_error':max_matrix,'max_tower_error':max_tower}

def configurations():
    ds=[.02,.05,.10,.20,.40]
    taus=[0.]+np.geomspace(.001,.5,16).tolist()
    configs=[('always_helpful',0.),('deployed',.7)]
    configs += [(family,float(v)) for family in ['turn_message','turn_memory'] for v in taus]
    configs += [('crisis',v) for v in [.1,.2,.35,.5,.7]]
    configs += [('CRA',v) for v in [.2,.35,.45,.6,.8]]
    configs += [(family,v) for family in ['shield','original_exact','budget_exact','budget_myopic'] for v in ds]
    return configs

def plot_results(tag,results,out):
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(8,5))
    styles={'turn_message':('#4263eb','o'),'turn_memory':('#1098ad','s'),
            'original_exact':('#7950f2','^'),'budget_exact':('#2b8a3e','*'),
            'budget_myopic':('#e67700','D'),'shield':('#868e96','v'),
            'crisis':('#c92a2a','x'),'CRA':('#d6336c','+'),
            'always_helpful':('#343a40','.'),'deployed':('#343a40','x')}
    for family,(color,marker) in styles.items():
        pts=[x for x in results if x['method']==family]
        if not pts:continue
        ax.scatter([x['utility'] for x in pts],[100*x['harm'] for x in pts],color=color,marker=marker,alpha=.35,s=25)
        nd=[x for x in pts if not any(y['utility']>=x['utility'] and y['harm']<=x['harm'] and
                                    (y['utility']>x['utility'] or y['harm']<x['harm']) for y in pts)]
        nd=sorted(nd,key=lambda x:x['utility'])
        ax.plot([x['utility'] for x in nd],[100*x['harm'] for x in nd],marker=marker,color=color,label=family)
    ax.set(xlabel='Mean helpfulness',ylabel='Episodes reaching harm (%)',title=f'{tag}: validation only, {N_EPISODES_PER_PROFILE} episodes/profile')
    ax.grid(alpha=.2);ax.legend(fontsize=8,ncol=2);fig.tight_layout()
    fig.savefig(out/f'{tag}_validation.png',dpi=170);fig.savefig(out/f'{tag}_validation.pdf')
    ax.set(xlim=(.60,.75),ylim=(0,20),title=f'{tag}: validation detail, helpfulness 0.60–0.75')
    fig.savefig(out/f'{tag}_validation_focus.png',dpi=170)
    fig.savefig(out/f'{tag}_validation_focus.pdf');plt.close(fig)

def run():
    global S
    root=inputs();out=Path(OUTPUT_DIR).resolve();out.mkdir(parents=True,exist_ok=True)
    if VALIDATION_OFFSET!=200000:raise ValueError('Questo script esegue solo validazione: offset 200000.')
    if not 2<=N_EPISODES_PER_PROFILE<=1000:raise ValueError('Usare 2–1000 episodi/profilo per varianza e separazione dei seed.')
    cwd=os.getcwd()
    try:
        os.chdir(root);S={'__name__':'supplied_original_core'};exec(compile(CORE_SOURCE,'original_core','exec'),S)
    finally:os.chdir(cwd)
    configs=configurations()
    protocol={'version':VERSION,'phase':'validation_only','validation_offset':VALIDATION_OFFSET,
              'reserved_test_offset_not_executed':900000,'n_per_profile':N_EPISODES_PER_PROFILE,
              'environments':['unit','acc'],'primary_environment':'unit',
              'utility_targets':[.60,.65,.70,.75], 'configurations':configs,
              'core_sha256':hashlib.sha256(CORE_SOURCE.encode()).hexdigest(),
              'corpus_sha256':hashlib.sha256((root/'llm_corpus/corpus.jsonl').read_bytes()).hexdigest(),
              'budget_candidate':'Exact safe-continuation mass with model-specific observation-contingent episode budgets.',
              'limits':'No GFlowNet retraining in this phase; exact enumeration isolates the budget mechanism. '
                       'No baseline-containment or dominance claim. Conditional guarantee only under models in Theta. '
                       'Same corpus, profiles and dynamics; new seeds are not a new population. Wilson intervals '
                       'are approximate descriptive summaries; comparisons require paired analysis on held-out tests.'}
    protocol_path=out/'validation_protocol.json'
    if protocol_path.exists() and json.loads(protocol_path.read_text())!=json.loads(json.dumps(protocol,default=serial)):
        raise ValueError('Protocollo diverso: usare una nuova OUTPUT_DIR.')
    dump(protocol_path,protocol)  # written before evaluating any configuration
    all_results={};selection={}
    for tag,acc in [('unit',False),('acc',True)]:
        start=time.time();users,tables,g=S['build'](acc=acc,iters=0)
        kernels={k:Kernel(tb.ens) for k,(tb,xu) in tables.items()}
        checks=check_certificate(users,tables,kernels);dump(out/f'{tag}_checks.json',checks)
        results=[]
        for ci,(family,param) in enumerate(configs):
            rows=[]
            for ui,(key,user) in enumerate(users.items()):
                tb,xu=tables[key]
                for ep in range(N_EPISODES_PER_PROFILE):
                    seed=VALIDATION_OFFSET+1000*ui+ep
                    row=episode(family,param,user,tb,kernels[key],xu,g,seed,seed+4000000)
                    row.update(profile=key,episode=ep,seed=seed);rows.append(row)
            summary=summarize(rows);summary.update(method=family,parameter=param)
            results.append(summary)
            dump(out/f'{tag}_{ci:02d}_episodes.json',{'method':family,'parameter':param,'episodes':rows})
            dump(out/f'{tag}_results.json',results)
            print(f'{tag} {ci+1}/{len(configs)} {family:17s} {param:.5g}: '
                  f'harm={100*summary["harm"]:5.1f}% help={summary["utility"]:.3f} '
                  f'fallback={100*summary["fallback"]:5.1f}%',flush=True)
        all_results[tag]=results;selection[tag]={}
        for target in protocol['utility_targets']:
            chosen={}
            for family in sorted({c[0] for c in configs}):
                feasible=[x for x in results if x['method']==family and x['utility']>=target]
                if feasible:
                    best=min(feasible,key=lambda x:(x['harm'],-x['utility']))
                    chosen[family]={'parameter':best['parameter'],'validation_harm':best['harm'],'validation_utility':best['utility']}
                else:chosen[family]=None
            selection[tag][str(target)]=chosen
        plot_results(tag,results,out)
        print(tag+' completed in '+str(round(time.time()-start,1))+' s',flush=True)
    dump(out/'validation_results.json',all_results)
    dump(out/'operating_points_selected_on_validation.json',selection)
    flat=[{'environment':tag,**{k:x[k] for k in ['method','parameter','n','harm_count','harm','utility','fallback','emergency']}}
          for tag,rows in all_results.items() for x in rows]
    with (out/'validation_summary.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(flat[0]));w.writeheader();w.writerows(flat)
    archive=out.parent/(out.name+'.zip')
    names=['validation_protocol.json','validation_results.json','operating_points_selected_on_validation.json','validation_summary.csv']
    for tag in ['unit','acc']:
        names += [f'{tag}_checks.json',f'{tag}_results.json',f'{tag}_validation.png',f'{tag}_validation.pdf',
                  f'{tag}_validation_focus.png',f'{tag}_validation_focus.pdf']
        names += [f'{tag}_{i:02d}_episodes.json' for i in range(len(configs))]
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for name in names:z.write(out/name,name)
    print('Validation complete. Test offset 900000 NOT executed. Output:',archive,flush=True)
    if DOWNLOAD_RESULTS:
        try:
            from google.colab import files
            files.download(str(archive))
        except ImportError:pass
    return all_results

if RUN_VALIDATION:
    try:
        from threadpoolctl import threadpool_limits
        ctx=threadpool_limits(limits=1)
    except ImportError:ctx=contextlib.nullcontext()
    with ctx:RESULTS=run()
