# GFlowNet vs exact safe-continuation mass: training on visited beliefs, conditioning on admissible plans,
# check on validation seeds (300000) and evaluation on unseen test seeds (960000). Run: GFN_ROOT=simulator python experiments/gflownet_vs_exact.py
import os, ast, json, math, time, zipfile, csv
from pathlib import Path
import numpy as np

MODE = os.environ.get('GFN_MODE', 'final')            # 'final' or 'smoke' (quick check)
LOCAL_ROOT = os.environ.get('GFN_ROOT')                # path to simulator/ when running outside Colab
def find_inputs():
    """Locate validation_engine.py in the Colab session, in Drive, or inside safe_futures_final*.zip."""
    bases = [Path('/content'), Path('/content/drive/MyDrive')]
    for base in bases:
        for cand in [base / 'safe_futures_final' / 'inputs', base / 'inputs']:
            if (cand / 'validation_engine.py').exists():
                return cand
    for base in bases:
        if base.exists():
            for hit in base.rglob('validation_engine.py'):
                if (hit.parent / 'llm_corpus' / 'corpus.jsonl').exists():
                    return hit.parent
    for base in bases:
        if base.exists():
            for z in sorted(base.rglob('safe_futures_final*.zip')):
                target = Path('/content/safe_futures_final_extracted')
                with zipfile.ZipFile(z) as zf:
                    names = [n for n in zf.namelist() if n.startswith('inputs/') and not n.endswith('/')]
                    if not any(n.endswith('validation_engine.py') for n in names):
                        continue
                    for n in names:
                        p = target / n
                        p.parent.mkdir(parents=True, exist_ok=True)
                        p.write_bytes(zf.read(n))
                print('Inputs extracted from', z)
                return target / 'inputs'
    raise FileNotFoundError("Simulator inputs not found: set GFN_ROOT to the simulator/ folder of the repository.")


if LOCAL_ROOT is None:
    from google.colab import drive
    drive.mount('/content/drive')
    ROOT = find_inputs()
    print('Input:', ROOT)
    OUT = Path('/content/drive/MyDrive/gfn_fix_' + MODE)
else:
    ROOT = Path(LOCAL_ROOT)
    OUT = Path(os.environ.get('GFN_OUT', 'gfn_fix_' + MODE))
SMOKE = MODE == 'smoke'
DELTAS = [float(x) for x in os.environ.get('GFN_DELTAS', '0.02,0.05,0.10').split(',')]
CONDITIONS = [c for c in [('unit', False, -2.0), ('acc', True, -2.0), ('unit_weak_fallback', False, -1.0)]
              if c[0] in os.environ.get('GFN_CONDITIONS', 'unit,acc,unit_weak_fallback').split(',')]
POOL_OFFSET, CHECK_OFFSET, TEST_OFFSET = 200000, 300000, 960000
N_POOL = int(os.environ.get('GFN_POOL', 2 if SMOKE else 60))
N_CHECK = int(os.environ.get('GFN_CHECK', 2 if SMOKE else 100))
N_TEST = int(os.environ.get('GFN_TEST', 2 if SMOKE else 200))
N_TRAIN = int(os.environ.get('GFN_TRAIN', 60 if SMOKE else 6000))
BATCH, EPS, SYNTH_FRAC, VOTES = 32, 0.2, 0.25, 64
DECISION = os.environ.get('GFN_DECISION', 'marginal')   # 'marginal': argmax of the estimated mass; 'vote': majority over VOTES samples
assert (ROOT / 'validation_engine.py').exists(), 'validation_engine.py not found in GFN_ROOT'
OUT.mkdir(parents=True, exist_ok=True)


def build_engine(tag, acc, pressure):
    text = (ROOT / 'validation_engine.py').read_text()
    module = ast.parse(text)
    module.body = [n for n in module.body if not (isinstance(n, ast.If) and isinstance(n.test, ast.Name)
                                                 and n.test.id == 'RUN_VALIDATION')]
    V = {'__name__': 'validation_definitions'}
    exec(compile(module, 'validation_engine', 'exec'), V)
    S = {'__name__': 'original_core'}
    cwd = os.getcwd()
    try:
        os.chdir(ROOT)
        exec(compile(V['CORE_SOURCE'], 'original_core', 'exec'), S)
    finally:
        os.chdir(cwd)
    S['PRESSURE'] = S['PRESSURE'].copy()
    S['PRESSURE'][4] = pressure
    S['STRATEGIES'] = list(S['STRATEGIES'])
    name, _, utility = S['STRATEGIES'][4]
    S['STRATEGIES'][4] = (name, pressure, utility)
    S['_TM_CACHE'].clear()
    V['S'] = S
    users, tables, _ = S['build'](acc=acc, iters=0)
    kernels = {p: V['Kernel'](tb.ens) for p, (tb, xu) in tables.items()}
    return dict(tag=tag, acc=acc, V=V, S=S, users=users, tables=tables, kernels=kernels)


def admissible_and_reward(C, tb, b, ell, delta):
    S = C['S']
    F = np.asarray(tb.F_at(ell))
    ok = np.einsum('ms,mps->mp', b, F).min(axis=0) >= 1 - delta
    R = (b.mean(axis=0) @ F[0].T) * np.exp(S['BETA'] * S['UTIL'][PLANS].sum(axis=1))
    return ok, np.where(ok, R, 0.0)


def exact_action(C, tb, b, ell, delta):
    ok, R = admissible_and_reward(C, tb, b, ell, delta)
    if not ok.any():
        return 4, True
    return int(np.bincount(PLANS[:, 0], weights=R, minlength=5).argmax()), False


def collect(C, delta, n_ep, offset):
    S, V = C['S'], C['V']
    states = []
    for ui, (p, user) in enumerate(C['users'].items()):
        tb, xu = C['tables'][p]
        for ep in range(n_ep):
            env = np.random.default_rng(offset + 1000 * ui + ep)
            q = np.zeros((len(tb.ens), 2, 5))
            q[:, 0, 0] = 1.0
            z, ell = 0, 0.0
            for t in range(30):
                b = q.sum(axis=1)
                states.append((p, b.copy(), ell))
                a, _ = exact_action(C, tb, b, ell, delta)
                P, e = S['model_step'](user, a, ell)
                z = env.choice(5, p=P[z])
                obs = S['emit'](user, z, env)
                q, _ = V['augmented_update'](q, tb.ens, a, ell, obs)
                ell = e
    return states


class CondGFN:
    """GFlowNet conditioned on nominal belief, profile, influence load and admissible-plan indicator."""
    def __init__(self, S, use_ell, seed=1):
        self.S, self.use_ell = S, use_ell
        self.nc = 5 + 3 + (1 if use_ell else 0) + len(PLANS)
        self.dim = self.nc + 2 + 2 * 5
        self.net = S['MLP']([self.dim, 64, 64, 5], seed=seed, lr=5e-4)
        self.zn = S['MLP']([self.nc, 32, 1], seed=seed + 7, lr=1e-3)

    def cond(self, bn, xu, ell, ok):
        parts = [bn, xu] + ([np.array([ell])] if self.use_ell else []) + [ok.astype(float)]
        return np.concatenate(parts)

    def row(self, c, step, prefix):
        x = np.zeros(self.dim)
        x[:self.nc] = c
        x[self.nc + step] = 1.0
        for j, a in enumerate(prefix):
            x[self.nc + 2 + j * 5 + a] = 1.0
        return x

    @staticmethod
    def allowed(ok, prefix):
        m = ok.copy()
        for j, a in enumerate(prefix):
            m &= PLANS[:, j] == a
        mask = np.zeros(5, bool)
        mask[np.unique(PLANS[m, len(prefix)])] = True
        return mask

    def probs(self, c, step, prefix):
        mask = self.allowed_cache[(step, tuple(prefix))]
        lp = self.S['log_softmax_masked'](self.net.forward(self.row(c, step, prefix)[None]), mask[None])[0]
        p = np.exp(lp)
        return p / p.sum(), mask

    def sample(self, c, ok, n, rng, eps=0.0):
        self.allowed_cache = {}
        self.allowed_cache[(0, ())] = self.allowed(ok, [])
        p0, m0 = self.probs(c, 0, [])
        if eps > 0:
            p0 = (1 - eps) * p0 + eps * m0 / m0.sum()
        a0 = rng.choice(5, size=n, p=p0 / p0.sum())
        plans = []
        for a in np.unique(a0):
            k = int((a0 == a).sum())
            self.allowed_cache[(1, (int(a),))] = self.allowed(ok, [int(a)])
            p1, m1 = self.probs(c, 1, [int(a)])
            if eps > 0:
                p1 = (1 - eps) * p1 + eps * m1 / m1.sum()
            a1 = rng.choice(5, size=k, p=p1 / p1.sum())
            plans += [(int(a), int(x)) for x in a1]
        return plans

    def train_step(self, c, ok, R, rng):
        plans = self.sample(c, ok, BATCH, rng, EPS)
        idx = np.array([p[0] * 5 + p[1] for p in plans])
        logR = np.log(np.maximum(R[idx], 1e-12))
        X = np.array([self.row(c, s, list(p[:s])) for p in plans for s in range(2)])
        ACT = np.array([p[s] for p in plans for s in range(2)])
        mask = np.array([self.allowed(ok, list(p[:s])) for p in plans for s in range(2)])
        ls = self.S['log_softmax_masked'](self.net.forward(X), mask)
        logpf = ls[np.arange(len(X)), ACT].reshape(len(plans), 2).sum(1)
        lz = self.zn.forward(c[None])[0, 0]
        resid = lz + logpf - logR
        d = 2 * resid / len(plans)
        dout = -np.exp(ls) * np.repeat(d, 2)[:, None]
        dout[np.arange(len(X)), ACT] += np.repeat(d, 2)
        self.net.backward(dout)
        self.zn.forward(c[None])
        self.zn.backward(np.array([[float(d.sum())]]))
        return float((resid ** 2).mean())

    def first_marginal(self, c, ok):
        self.allowed_cache = {(0, ()): self.allowed(ok, [])}
        return self.probs(c, 0, [])[0]


def synthetic_belief(rng):
    z = rng.choice(5, p=[0.35, 0.30, 0.20, 0.10, 0.05])
    b = np.full(5, 0.05) + np.eye(5)[z] * rng.uniform(0.5, 3.0)
    b = b + rng.dirichlet(np.ones(5) * 0.5) * 0.3
    return b / b.sum()


def train(C, delta, pool, seed):
    g = CondGFN(C['S'], C['acc'], seed=1)
    rng = np.random.default_rng(seed)
    profiles = list(C['tables'])
    losses, skipped = [], 0
    for it in range(N_TRAIN):
        for _ in range(100):
            if rng.random() < SYNTH_FRAC:
                p = profiles[rng.integers(len(profiles))]
                b = np.repeat(synthetic_belief(rng)[None], len(C['tables'][p][0].ens), 0)
                ell = float(rng.uniform(-2.0, 2.0)) if C['acc'] else 0.0
            else:
                p, b, ell = pool[rng.integers(len(pool))]
            tb, xu = C['tables'][p]
            ok, R = admissible_and_reward(C, tb, b, ell, delta)
            if ok.any():
                break
            skipped += 1
        else:
            continue
        losses.append(g.train_step(g.cond(b.mean(0), xu, ell, ok), ok, R, rng))
        if (it + 1) % 1000 == 0 or it + 1 == N_TRAIN:
            print(f"  {C['tag']} delta={delta}: {it + 1}/{N_TRAIN}, loss {np.mean(losses[-200:]):.4f}", flush=True)
    return g, len(losses), skipped


def make_gfn_action(C):
    def gfn_action(g, tb, b, ell, xu, delta, random):
        ok, _ = admissible_and_reward(C, tb, b, ell, delta)
        if not ok.any():
            return 4, True
        p = g.first_marginal(g.cond(b.mean(axis=0), xu, ell, ok), ok)
        if DECISION == 'marginal':
            return int(p.argmax()), False
        return int(np.bincount(random.choice(5, size=VOTES, p=p), minlength=5).argmax()), False
    return gfn_action


def fidelity(C, g, delta, states, rng, n_modes_states=300):
    act = make_gfn_action(C)
    match = n = 0
    tv = []
    coverage, single = [], []
    examples = []
    for i, (p, b, ell) in enumerate(states):
        tb, xu = C['tables'][p]
        ok, R = admissible_and_reward(C, tb, b, ell, delta)
        if not ok.any():
            continue
        ea = int(np.bincount(PLANS[:, 0], weights=R, minlength=5).argmax())
        ga, _ = act(g, tb, b, ell, xu, delta, rng)
        n += 1
        match += int(ga == ea)
        exact_marg = np.bincount(PLANS[:, 0], weights=R, minlength=5)
        exact_marg = exact_marg / exact_marg.sum()
        gm = g.first_marginal(g.cond(b.mean(0), xu, ell, ok), ok)
        tv.append(0.5 * float(np.abs(exact_marg - gm).sum()))
        if len(coverage) < n_modes_states:
            target = R / R.sum()
            modes = np.flatnonzero(target >= 0.5 * target.max())
            plans = g.sample(g.cond(b.mean(0), xu, ell, ok), ok, 64, rng)
            cnt = np.bincount([a * 5 + c for a, c in plans], minlength=25)
            coverage.append(float(np.mean(cnt[modes] > 0)))
            single.append(1.0 / len(modes))
            if len(examples) < 3 and len(modes) >= 3 and (not examples or examples[-1]['profile'] != p):
                big = g.sample(g.cond(b.mean(0), xu, ell, ok), ok, 3000, rng)
                freq = np.bincount([a * 5 + c for a, c in big], minlength=25) / 3000
                examples.append({'profile': p, 'plans': PLANS.tolist(), 'exact': target.tolist(),
                                 'sampled': freq.tolist(), 'n_modes': int(len(modes))})
    return {'action_agreement': match / n if n else None, 'states': n,
            'mean_tv_first_action': float(np.mean(tv)) if tv else None,
            'mode_coverage_gfn': float(np.mean(coverage)) if coverage else None,
            'mode_coverage_single_solution': float(np.mean(single)) if single else None,
            'examples': examples}


def mcnemar(a, b):
    ha, hb = np.array([r['harm'] for r in a]), np.array([r['harm'] for r in b])
    only_a, only_b = int(np.sum((ha == 1) & (hb == 0))), int(np.sum((ha == 0) & (hb == 1)))
    d = only_a + only_b
    p = min(1.0, 2 * sum(math.comb(d, k) for k in range(min(only_a, only_b) + 1)) / 2 ** d) if d else 1.0
    return only_a, only_b, p


def run_episodes(C, kind, delta, g, offset, n):
    V = C['V']
    rows = []
    for ui, (p, user) in enumerate(C['users'].items()):
        tb, xu = C['tables'][p]
        for ep in range(n):
            seed = offset + 1000 * ui + ep
            r = V['episode'](kind, delta, user, tb, C['kernels'][p], xu, g, seed, seed + 4000000)
            r.update(profile=p, episode=ep, seed=seed)
            rows.append(r)
    return rows


def save_model(g, path):
    vals = {}
    for label, net in [('net', g.net), ('zn', g.zn)]:
        for name in ['W', 'b']:
            for i, x in enumerate(getattr(net, name)):
                vals[f'{label}_{name}_{i}'] = x
    np.savez_compressed(path, **vals)


t0 = time.time()
results = []
for ci, (tag, acc, pressure) in enumerate(CONDITIONS):
    C = build_engine(tag, acc, pressure)
    PLANS = C['V']['PLANS']
    C['V']['original_gfn_action'] = make_gfn_action(C)
    for di, delta in enumerate(DELTAS):
        print(f"\n{tag} delta={delta}: collecting validation states", flush=True)
        pool = collect(C, delta, N_POOL, POOL_OFFSET)
        g, updates, skipped = train(C, delta, pool, seed=7000000 + 1000 * ci + 10 * di)
        save_model(g, OUT / f'gfn_{tag}_{delta:.2f}.npz')
        check_states = collect(C, delta, N_CHECK, CHECK_OFFSET)
        check = fidelity(C, g, delta, check_states, np.random.default_rng(11 + ci * 10 + di))
        frozen = {'condition': tag, 'delta': delta, 'updates': updates, 'skipped_states': skipped,
                  'check_offset': CHECK_OFFSET, **{k: v for k, v in check.items() if k != 'examples'}}
        (OUT / f'frozen_{tag}_{delta:.2f}.json').write_text(json.dumps(frozen, indent=1))
        print(f"  check (seed {CHECK_OFFSET}): action agreement {100 * check['action_agreement']:.1f}%, "
              f"TV {check['mean_tv_first_action']:.3f}, mode coverage {100 * check['mode_coverage_gfn']:.0f}% "
              f"(single solution {100 * check['mode_coverage_single_solution']:.0f}%)", flush=True)
        ex = run_episodes(C, 'original_exact', delta, None, TEST_OFFSET, N_TEST)
        gf = run_episodes(C, 'original_gfn', delta, g, TEST_OFFSET, N_TEST)
        only_gfn, only_exact, p = mcnemar(gf, ex)
        test_states = collect(C, delta, N_TEST, TEST_OFFSET)
        test_fid = fidelity(C, g, delta, test_states, np.random.default_rng(99 + ci * 10 + di), n_modes_states=300)
        row = {'condition': tag, 'delta': delta, 'updates': updates,
               'check_agreement': check['action_agreement'], 'check_tv': check['mean_tv_first_action'],
               'test_agreement': test_fid['action_agreement'], 'test_tv': test_fid['mean_tv_first_action'],
               'test_mode_coverage_gfn': test_fid['mode_coverage_gfn'],
               'test_mode_coverage_single': test_fid['mode_coverage_single_solution'],
               'exact_harm': float(np.mean([r['harm'] for r in ex])), 'exact_help': float(np.mean([r['utility'] for r in ex])),
               'gfn_harm': float(np.mean([r['harm'] for r in gf])), 'gfn_help': float(np.mean([r['utility'] for r in gf])),
               'gfn_only_harm': only_gfn, 'exact_only_harm': only_exact, 'mcnemar_p': p,
               'exact_fallback': float(np.mean([r['fallback'] for r in ex])), 'gfn_fallback': float(np.mean([r['fallback'] for r in gf])),
               'exact_emergency': float(np.mean([r['emergency'] for r in ex])), 'gfn_emergency': float(np.mean([r['emergency'] for r in gf]))}
        results.append(row)
        (OUT / f'examples_{tag}_{delta:.2f}.json').write_text(json.dumps(test_fid['examples']))
        print(f"  test (seed {TEST_OFFSET}): exact {100 * row['exact_harm']:.2f}% / {row['exact_help']:.3f}  "
              f"GFlowNet {100 * row['gfn_harm']:.2f}% / {row['gfn_help']:.3f}  McNemar p={p:.3f}  "
              f"agreement {100 * row['test_agreement']:.1f}%  [{time.time() - t0:.0f} s]", flush=True)

with open(OUT / 'gfn_fix_results.csv', 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(results[0]))
    w.writeheader()
    w.writerows(results)
(OUT / 'gfn_fix_results.json').write_text(json.dumps(results, indent=1))
print('\nSUMMARY (harm % / helpfulness)')
for r in results:
    print(f"{r['condition']:<20} delta={r['delta']:<5} exact {100 * r['exact_harm']:5.2f}/{r['exact_help']:.3f}  "
          f"GFN {100 * r['gfn_harm']:5.2f}/{r['gfn_help']:.3f}  p={r['mcnemar_p']:.3f}  "
          f"check agreement {100 * r['check_agreement']:.1f}%  test {100 * r['test_agreement']:.1f}%")
archive = OUT.with_suffix('.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for pth in sorted(OUT.rglob('*')):
        if pth.is_file():
            z.write(pth, pth.relative_to(OUT))
print('Done:', archive, f'in {time.time() - t0:.0f} s')
try:
    from google.colab import files
    files.download(str(archive))
except Exception:
    pass
