"""Reproduce the result figures of the paper from the CSV/JSON files in results/."""
import csv, json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
MAIN, GFN, OUT = ROOT / 'results' / 'main', ROOT / 'results' / 'gflownet', ROOT / 'figures'
R = {t: json.load(open(MAIN / f'{t}_results.json')) for t in ['unit', 'acc', 'unit_weak_fallback']}
COL = {'always_helpful': '#adb5bd', 'deployed': '#868E96', 'turn_message': '#4C6EF5', 'turn_memory': '#15AABF',
       'crisis': '#E8590C', 'CRA': '#F08C00', 'shield': '#7048E8', 'original_exact': '#2B8A3E'}
NAME = {'always_helpful': 'always helpful', 'deployed': 'deployed-like', 'turn_message': 'turn-level filter (message)',
        'turn_memory': 'turn-level filter (memory)', 'crisis': 'crisis detection', 'CRA': 'multi-turn risk accumulation',
        'shield': 'shield + myopic', 'original_exact': 'proposed'}
# operating point delta = 0.05 in the main environment; filter thresholds matched on validation episodes
OP = [('always_helpful', 0.0), ('deployed', 0.7), ('crisis', 0.35), ('CRA', 0.45), ('shield', 0.05),
      ('turn_message', 0.14426999059072135), ('turn_memory', 0.007937005259840991), ('original_exact', 0.05)]


def get(t, m, p):
    for r in R[t]:
        if r['method'] == m and abs(r['parameter'] - p) < 1e-9:
            return r
    raise KeyError((t, m, p))


def style(ax, axis='both'):
    ax.spines[['top', 'right']].set_visible(False)
    ax.grid(alpha=.25, lw=.5, axis=axis)
    ax.set_axisbelow(True)


# relative reduction in harm (summary.pdf)
prop = get('unit', 'original_exact', 0.05)['harm']
rows = sorted([(m, get('unit', m, p)['harm']) for m, p in OP[:-1]], key=lambda x: 100 * (1 - prop / x[1]))
vals = [100 * (1 - prop / h) for _, h in rows]
fig, ax = plt.subplots(figsize=(6.6, 3.6))
ax.barh([f"{NAME[m]}\n({100 * h:.1f}% harm)" for m, h in rows], vals,
        color=['#2B8A3E' if v > 0 else '#adb5bd' for v in vals])
for y, v in enumerate(vals):
    ax.text(v + (1.5 if v >= 0 else -1.5), y, f"{v:.0f}%", va='center', ha='left' if v >= 0 else 'right', fontsize=8, color='#495057')
ax.axvline(0, color='#495057', lw=.6)
ax.set_xlabel('relative reduction in harm obtained by the proposed scheme (%)')
ax.tick_params(axis='y', labelsize=7); ax.set_xlim(-30, 110); style(ax)
fig.tight_layout(); fig.savefig(OUT / 'summary.pdf'); plt.close(fig)

# safety-helpfulness frontiers (pareto.pdf)
FAM = ['turn_message', 'turn_memory', 'crisis', 'CRA', 'shield', 'original_exact']
XL = {'unit': (0.63, 0.73), 'acc': (0.63, 0.75), 'unit_weak_fallback': (0.55, 0.69)}
fig, axs = plt.subplots(1, 3, figsize=(12, 3.8), sharey=True)
for ax, t, lab in zip(axs, ['unit', 'acc', 'unit_weak_fallback'], ['(a)', '(b)', '(c)']):
    for m in FAM:
        pts = sorted([(r['utility'], 100 * r['harm']) for r in R[t] if r['method'] == m and r['status'] == 'complete'])
        ax.plot([p[0] for p in pts], [p[1] for p in pts], '-', marker='*' if m == 'original_exact' else 'o',
                ms=8 if m == 'original_exact' else 3.5, lw=2.2 if m == 'original_exact' else 1.2, color=COL[m], label=NAME[m])
    ax.set_xlim(*XL[t]); ax.set_ylim(0, 30); ax.set_xlabel('helpfulness (utility per turn)'); style(ax)
    ax.text(0.02, 0.95, lab, transform=ax.transAxes, fontsize=9, va='top')
axs[0].set_ylabel('harm (%)')
h, l = axs[0].get_legend_handles_labels()
fig.legend(h, l, fontsize=8, frameon=False, ncol=6, loc='lower center', bbox_to_anchor=(0.5, -0.03))
fig.tight_layout(rect=[0, 0.08, 1, 1]); fig.savefig(OUT / 'pareto.pdf', bbox_inches='tight'); plt.close(fig)

# evolution along the conversation (dynamics.pdf)
D = {}
for r in csv.DictReader(open(MAIN / 'dynamics_unit.csv')):
    D.setdefault(r['method'], []).append((int(r['turn']), float(r['cumulative_harm_pct']), float(r['average_stage'])))
fig, ax = plt.subplots(1, 2, figsize=(9, 3.4))
for m, _ in OP:
    d = sorted(D[m]); lw = 2.4 if m == 'original_exact' else 1.3
    ax[0].plot([x[0] for x in d], [x[1] for x in d], color=COL[m], lw=lw, label=NAME[m])
    ax[1].plot([x[0] for x in d], [x[2] for x in d], color=COL[m], lw=lw)
ax[0].set_ylabel('cumulative harm (%)'); ax[1].set_ylabel('average escalation stage')
for a in ax:
    a.set_xlabel('conversation turn'); style(a)
h, l = ax[0].get_legend_handles_labels()
fig.legend(h, l, fontsize=7.5, frameon=False, ncol=4, loc='lower center', bbox_to_anchor=(0.5, -0.04))
fig.tight_layout(rect=[0, 0.13, 1, 1]); fig.savefig(OUT / 'dynamics.pdf', bbox_inches='tight'); plt.close(fig)

# three environments at delta = 0.02 (avg.pdf)
fz = json.load(open(MAIN / 'frozen_before_test.json'))['selection']
conds = ['unit', 'acc', 'unit_weak_fallback']
pol = [('shield', lambda t: 0.02),
       ('turn_memory', lambda t: [x for x in fz[t]['matches'] if x['delta'] == 0.02][0]['memory_tau']),
       ('original_exact', lambda t: 0.02)]
fig, ax = plt.subplots(1, 2, figsize=(8.6, 3.2)); x = np.arange(3); w = .26
for i, (m, f) in enumerate(pol):
    H = [100 * get(t, m, f(t))['harm'] for t in conds]; U = [get(t, m, f(t))['utility'] for t in conds]
    ax[0].bar(x + (i - 1) * w, H, w, color=COL[m], label=NAME[m]); ax[1].bar(x + (i - 1) * w, U, w, color=COL[m])
    for xi, hv, uv in zip(x + (i - 1) * w, H, U):
        ax[0].text(xi, hv + 0.15, f"{hv:.1f}", ha='center', fontsize=7); ax[1].text(xi, uv + 0.006, f"{uv:.2f}", ha='center', fontsize=7)
for a, lab in ((ax[0], 'harm (%)'), (ax[1], 'helpfulness')):
    a.set_xticks(x); a.set_xticklabels(['unit', 'accumulated\ninfluence', 'weaker\nfallback'], fontsize=8); a.set_ylabel(lab); style(a, 'y')
ax[1].set_ylim(0, 0.8)
h, l = ax[0].get_legend_handles_labels()
fig.legend(h, l, fontsize=8, frameon=False, ncol=3, loc='lower center', bbox_to_anchor=(0.5, -0.03))
fig.tight_layout(rect=[0, 0.09, 1, 1]); fig.savefig(OUT / 'avg.pdf', bbox_inches='tight'); plt.close(fig)

# exact target vs GFlowNet samples (fig_modes.pdf)
sets = [('unit', 'unit environment'), ('acc', 'accumulated influence'), ('unit_weak_fallback', 'weaker fallback')]
fig, axs = plt.subplots(3, 1, figsize=(7.6, 6.6))
for a, (t, lab) in zip(axs, sets):
    c = json.load(open(GFN / f'examples_{t}_0.05.json'))[0]
    e, s = np.array(c['exact']), np.array(c['sampled']); o = np.argsort(e)[::-1]; xx = np.arange(25)
    a.bar(xx - .2, e[o], .4, color='#495057', label='exact target'); a.bar(xx + .2, s[o], .4, color='#2B8A3E', label='GFlowNet samples')
    a.set_ylabel('probability'); a.set_xticks(xx); a.set_xticklabels([''.join(map(str, c['plans'][i])) for i in o], fontsize=6)
    a.text(.98, .85, f"{lab}, {c['n_modes']} modes", transform=a.transAxes, ha='right', fontsize=8, color='#495057'); style(a)
axs[0].legend(fontsize=8, frameon=False, ncol=2, loc='upper center'); axs[-1].set_xlabel('plan (sequence of two strategies)')
fig.tight_layout(); fig.savefig(OUT / 'fig_modes.pdf'); plt.close(fig)
print('Figures written to', OUT)
