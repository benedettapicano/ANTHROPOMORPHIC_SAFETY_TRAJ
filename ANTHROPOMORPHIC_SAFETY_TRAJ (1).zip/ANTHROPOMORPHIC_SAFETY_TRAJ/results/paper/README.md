Place here the output folder of the frozen evaluation produced by `experiments/gfn_paper_colab.py`
(`gfn_paper_horizons`), including `protocol_fixed_before_test.json`, the per-configuration results and the
report. `figure_data.json` collects the values used to draw the figures of the paper.
